<?php
$conn = mysqli_connect('localhost', 'root', '', 'school');

if (!$conn)
{
    echo "Error: Unable to connect to MySQL." . PHP_EOL;
    echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
    echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
    exit;
}

if (isset($_POST['submit']))
{
    $dname = $_POST['dname'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $pincode = $_POST['pincode'];
    $city = $_POST['city'];
    $aadhar = $_FILES['aadhar']['name'];
    $lincense = $_FILES['lincense']['name'];

    $uploaddir = 'uploads/';
    $uploadfile = $uploaddir . basename($_FILES['aadhar']['name']);

    echo "<p>";

    if (move_uploaded_file($_FILES['aadhar']['tmp_name'], $uploadfile))
    {
        echo "File is valid, and was successfully uploaded.\n";
    }
    else
    {
        echo "Upload failed";
    }

    $uploaddir_lincense = 'lincense/';
    $uploadfile_lincense = $uploaddir_lincense . basename($_FILES['lincense']['name']);

    echo "<p>";

    if (move_uploaded_file($_FILES['lincense']['tmp_name'], $uploadfile_lincense))
    {
        echo "File is valid, and was successfully uploaded.\n";
    }
    else
    {
        echo "Upload failed";
    }

    if ($dname != '' || $phone != '')
    {
        $query = "INSERT INTO driver_registration (dname,phone,address,pincode,city,aadhar,lincense) VALUES('$dname','$phone','$address','$pincode','$city','$aadhar','$lincense')";
        echo '<script language="javascript">';
        echo 'alert("Successfully Registered"); location.href="index.php"';
        echo '</script>';

    }
    else
    {
        echo "<script type='text/javascript'>alert('failed!')</script>";
    }
    //echo $query;
    $sql = mysqli_query($conn, $query);
    //echo $sql;
    //header("location: index.php");
    //exit;
    
}
//
mysqli_close($conn);
?>

<html lang="en">
   <head>
      <meta charset="utf-8">
      <title>Ever Driver</title>
      <meta content="width=device-width, initial-scale=1.0" name="viewport">
      <meta content="" name="keywords">
      <meta content="" name="description">
      <!-- Favicons -->
      <link href="img/favicon.ico" rel="icon">
      <link href="img/apple-touch-icon.png" rel="apple-touch-icon">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
      <script type="text/javascript">
         $(document).ready(function(){
         	$("#body").modal('show');
         });
      </script>
      <style>
         body{
         background: #ff0000;
         }
         .container{
         background: #f8f9fa;
         margin-top:21px;
         }
         .error {color: #FF0000;}
         span {
         text-align:center;
         color:#000000;
         }
      </style>
   </head>
   <body>
      <div id="body" class="modal fade">
         <div class="modal-dialog">
            <div class="modal-content">
               <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                  <h2 class="text-center bg-primary text-white">Driver Registration</h2>
               </div>
               <div class="modal-body">
                  <div class="row">
                     <form class="form-horizontal" enctype="multipart/form-data" method="POST" action="driver_registration.php">
                        <div class="form-group" >
                           <label class="control-label col-xs-4"> Name <span class="error">*</span> : </label>
                           <div class="col-xs-6">
                              <input type="text" class="form-control" id="dname" name="dname" placeholder="Driver Name" required>
                           </div>
                        </div>
                        <div class="form-group">
                           <label class="control-label col-xs-4">Mobile No <span class="error">*</span> : </label>
                           <div class="col-xs-6">
                              <input type="text" class="form-control" id="phone" name="phone" placeholder="Phone/Mobile" required>
                           </div>
                        </div>
                        <div class="form-group">
                           <label class="control-label col-xs-4">Address <span class="error"></span> : </label>
                           <div class="col-xs-6">
                              <textarea name="address" class="form-control" id="address" type="text"  placeholder="As per Aadhar Card"></textarea>
                           </div>
                        </div>
                        <div class="form-group">
                           <label class="control-label col-xs-4">Pincode <span class="error">*</span> : </label>
                           <div class="col-xs-6">
                              <input type="text" class="form-control" id="pincode" name="pincode" placeholder="pincode" required>
                           </div>
                        </div>
                        <div class="form-group">
                           <label class="control-label col-xs-4">City<span class="error">*</span> : </label>
                           <div class="col-xs-6">
                              <input type="text" class="form-control" id="city" name="city" placeholder="city" required>
                           </div>
                        </div>
                        <div class="form-group">
                           <label class="control-label col-xs-4"> Upload Aadhaar Card <span class="error">*</span> : </label>
                           <div class="col-xs-6">
                              <input type="file" class="form-control" id="aadhar" name="aadhar" placeholder="aadhar">
                           </div>
                        </div>
                        <div class="form-group">
                           <label class="control-label col-xs-4"> Upload Driving Lincense<span class="error">*</span> : </label>
                           <div class="col-xs-6">
                              <input type="file" class="form-control" id="lincense" name="lincense" placeholder="lincense">
                           </div>
                        </div>
                        <div class="form-group" >
                           <div class="col-xs-offset-4 col-xs-10">
                              <button type="submit" class="btn btn-success" name="submit" id="register"  value="Submit" href="index.php" >Submit</button>
                              <a href="index.php" class="btn btn-info" role="button">Back to Home Page</a>
                           </div>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </body>
</html>