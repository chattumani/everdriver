<?php
$conn = mysqli_connect('localhost', 'root', '', 'school');

if (!$conn)
{
    echo "Error: Unable to connect to MySQL." . PHP_EOL;
    echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
    echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
    exit;
}

if (isset($_POST['submit']))
{
    $sname = $_POST['sname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $area = $_POST['area'];
    $typeofdriver = $_POST['typeofdriver'];

    if ($sname != '' || $email != '')
    {
        $query = "INSERT INTO contacts (sname,email,phone,area,typeofdriver) VALUES('$sname','$email','$phone','$area','$typeofdriver')";
        echo '<script language="javascript">';
        echo 'alert("Successfully Registered"); location.href="index.php"';
        echo '</script>';

    }
    else
    {
        echo "<script type='text/javascript'>alert('failed!')</script>";
    }
    
    $sql = mysqli_query($conn, $query);
    
    
}
//
mysqli_close($conn);
?>

<html lang="en">
   <head>
      <meta charset="utf-8">
      <title>Sagar International School</title>
      <meta content="width=device-width, initial-scale=1.0" name="viewport">
      <meta content="" name="keywords">
      <meta content="" name="description">
      <!-- Favicons -->
      <link href="img/favicon.ico" rel="icon">
      <link href="img/apple-touch-icon.png" rel="apple-touch-icon">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
      <script type="text/javascript">
         $(document).ready(function(){
         	$("#body").modal('show');
         });
      </script>
      <style>
         body{
         background:#ff0000;
         }
         .container{
         background: #f8f9fa;
         margin-top:21px;
         }
         .error {color: #FF0000;}
         span {
         text-align:center;
         color:#000000;
         }
      </style>
   </head>
   <body>
      <div id="body" class="modal fade">
         <div class="modal-dialog">
            <div class="modal-content">
               <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                  <h2 class="text-center bg-primary text-white">Driver Enquiry</h2>
               </div>
               <div class="modal-body">
                  <div class="row">
                     <form class="form-horizontal " method="POST" action="admission.php">
                        <div class="form-group" >
                           <label class="control-label col-xs-4"> Name <span class="error">*</span> : </label>
                           <div class="col-xs-6">
                              <input type="text" class="form-control" id="sname" name="sname" placeholder="Student Name" required>
                           </div>
                        </div>
                        <div class="form-group">
                           <label class="control-label col-xs-4">Email ID <span class="error"></span> : </label>
                           <div class="col-xs-6">
                              <input type="email" class="form-control" id="email" name="email" placeholder="Email" >
                           </div>
                        </div>
                        <div class="form-group">
                           <label class="control-label col-xs-4">Mobile No <span class="error">*</span> : </label>
                           <div class="col-xs-6">
                              <input type="text" class="form-control" id="phone" name="phone" placeholder="Phone/Mobile" required>
                           </div>
                        </div>
                        <div class="form-group">
                           <label class="control-label col-xs-4"> Living Area <span class="error">*</span> : </label>
                           <div class="col-xs-6">
                              <input type="text" class="form-control" id="area" name="area" placeholder="Current living area">
                           </div>
                        </div>
                        <div class="form-group">
                           <label class="control-label col-xs-4">Are u looking which driver <span class="error">*</span> : </label>
                           <div class="col-xs-6">
                              <select class="form-control" id="typeofdriver" name="typeofdriver"  required>
                                 <option selected>Choose...</option>
                                 <option value="tempdriver">Temporaily Driver</option>
                                 <option value="resdriver">Residential Driver</option>
                                 <option value="monthlydriver">Monthly Driver</option>
                              </select>
                           </div>
                        </div>
                        <div class="form-group" >
                           <div class="col-xs-offset-4 col-xs-10">
                              <button type="submit" class="btn btn-success" name="submit" id="register"  value="Submit" href="index.php" >Submit</button>
                              <a href="index.php" class="btn btn-info" role="button">Back to Home Page</a>
                           </div>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </body>
</html>