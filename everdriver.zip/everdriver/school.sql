-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 31, 2020 at 06:23 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school`
--

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `sname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `area` varchar(50) NOT NULL,
  `typeofdriver` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `sname`, `email`, `phone`, `area`, `typeofdriver`) VALUES
(1, 'Manish Chaturvedi', 'manish.chturvedi@gmail.com', '9179172460', 'fgf', 'tempdriver');

-- --------------------------------------------------------

--
-- Table structure for table `driver_registration`
--

CREATE TABLE `driver_registration` (
  `id` int(11) NOT NULL,
  `dname` varchar(100) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `address` varchar(255) NOT NULL,
  `pincode` int(50) NOT NULL,
  `city` varchar(100) NOT NULL,
  `aadhar` varchar(255) NOT NULL,
  `lincense` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `driver_registration`
--

INSERT INTO `driver_registration` (`id`, `dname`, `phone`, `address`, `pincode`, `city`, `aadhar`, `lincense`) VALUES
(1, 'manish ', '9179172460', 'mig 28 kahna kunj phase 1  kolar', 462042, 'BHOPAL', 'about.jpg', 'apple-touch-icon.png'),
(2, 'manish ', '9179172460', 'mig 28 kahna kunj phase 1  kolar', 462042, 'BHOPAL', '', ''),
(3, 'manish ', '9179172460', 'mig 28 kahna kunj phase 1  kolar', 462042, 'BHOPAL', '', ''),
(4, 'manish ', '9179172460', 'mig 28 kahna kunj phase 1  kolar', 462042, 'BHOPAL', '', ''),
(5, 'manish ', '9179172460', 'mig 28 kahna kunj phase 1  kolar', 462042, 'BHOPAL', '', ''),
(6, 'manish ', '9179172460', 'mig 28 kahna kunj phase 1  kolar', 462042, 'BHOPAL', '', ''),
(7, 'manish ', '9179172460', 'mig 28 kahna kunj phase 1  kolar', 462042, 'BHOPAL', 'about.jpg', 'comments-5.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `driver_registration`
--
ALTER TABLE `driver_registration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `driver_registration`
--
ALTER TABLE `driver_registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
