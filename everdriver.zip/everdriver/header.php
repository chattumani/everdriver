<header id="header" class="fixed-top">

    <div class="container-fluid d-flex align-items-center">
  <a href="index.php" class="logo mr-auto"><img src="assets/img/logo_new.jpeg" alt="" class="float-left" style="max-height:100px;"></a>
      <h1 class="logo mr-auto"><a href="index.html"><span><u>Ever</span> Driver</u></a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
       

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li class="active"><a href="index.php">Home</a></li>

          <li><a href="about.php">About</a>
            <!--<ul>
              <li><a href="about.html">About Us</a></li>
              <li><a href="team.html">Team</a></li>
              <li><a href="testimonials.html">Testimonials</a></li>
              <li class="drop-down"><a href="#">Deep Drop Down</a>
                <ul>
                  <li><a href="#">Deep Drop Down 1</a></li>
                  <li><a href="#">Deep Drop Down 2</a></li>
                  <li><a href="#">Deep Drop Down 3</a></li>
                  <li><a href="#">Deep Drop Down 4</a></li>
                  <li><a href="#">Deep Drop Down 5</a></li>
                </ul>
              </li>
            </ul>-->
          </li>

          <li class="drop-down"><a href="services.php">Services</a>
		  <ul>
              <li><a href="why_join.php">Why join Us</a></li>
             
            </ul>
		  
		  </li>
          <li><a href="driver_registration.php" target="_blank">Driver Registration</a></li>
          <li><a href="contact.php">Contact</a></li>

        </ul>
      </nav><!-- .nav-menu -->

      <div class="header-social-links">
        <a href="#" class="twitter"><i class="icofont-twitter"></i></a>
        <a href="#" class="facebook"><i class="icofont-facebook"></i></a>
        <a href="#" class="instagram"><i class="icofont-instagram"></i></a>
        <a href="#" class="linkedin"><i class="icofont-linkedin"></i></i></a>
      </div>

    </div>
  </header>